//
//  practifac5finaleje1App.swift
//  practifac5finaleje1
//
//  Created by alumno on 24/02/23.
//

import SwiftUI

@main
struct practifac5finaleje1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
